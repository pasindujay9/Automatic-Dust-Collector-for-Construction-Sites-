Pp = 5.5e-06 ;
u= 1.8e-04;

Vt= 14.1;
D= 290e-03;

tres =0.8* 1e10  ;

d = [ 1e-06, 2e-06, 3e-06, 4e-06 ,5e-06, 6e-06];

n = 1 - exp(-(Pp/(9.*u)).*(((2.*d.*Vt)/D ).^2).*tres) ;

plot(d, n, 'rx-');
hold on 

Vt = 17.3;
n = 1 - exp(-(Pp/(9.*u)).*(((2.*d.*Vt)/D ).^2).*tres) ;
plot (d, n, 'bx-');
hold on 

Vt = 20.9;
n = 1 - exp(-(Pp/(9.*u)).*(((2.*d.*Vt)/D ).^2).*tres) ;
plot (d, n, 'gx-')

xlabel('Particle Diameter (m)');
ylabel('Separation Efficiency');
title('Separation efficiency according to the particle diameter for various inlet velocities ');
legend('Vin = 10','Vin = 15','Vin = 20');
