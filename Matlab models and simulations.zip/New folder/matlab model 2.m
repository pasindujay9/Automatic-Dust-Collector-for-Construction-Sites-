D = 290e-03;
Vin = 10;
r1 = -0.290/2:0.01:-0.145/2;
r2 =0.145/2:0.01:0.290/2;
r = [r1 ,r2];
Vt = (Vin./abs(r).^0.52).*(D/2)^0.52;

scatter(r,Vt, 'rx');
xlabel('Position (m)');
ylabel('Tangential Velocity (m/s)')
